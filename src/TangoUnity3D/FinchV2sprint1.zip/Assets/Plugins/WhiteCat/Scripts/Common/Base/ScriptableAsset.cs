﻿using UnityEngine;

namespace WhiteCat
{
	/// <summary>
	/// ScriptableAsset
	/// </summary>
	public class ScriptableAsset : ScriptableObject
	{

	} // class ScriptableAsset

} // namespace WhiteCat