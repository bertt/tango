﻿The world topology texture used in this example (world.topo.jpg) has been provided by Reto Stöckli and the NASA Earth Observatory under the following terms:

General Terms of Use Information

Most images published in Visible Earth are freely available for re-publication or re-use, including commercial purposes, except for where copyright is indicated. In those cases you must obtain the copyright holder’s permission; we usually provide links to the organization that holds the copyright.
We ask that you use the credit statement attached with each image or else credit Visible Earth; the only mandatory credit is NASA.

http://visibleearth.nasa.gov/view.php?id=74443
