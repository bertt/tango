#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// This is a helper class containing the native iOS code for gesture recognition
@interface iOSGestures_Helper : UIViewController 
{
}


@end

